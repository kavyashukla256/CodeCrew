import requests
import random
from datetime import datetime, timezone
import time

API_URL = "http://127.0.0.1:8000/api/alerts/data/"

def send_sensor_data():
    data = {
        "location": random.choice(["Mumbai", "Chennai", "Goa", "Kochi"]),
        "wave_height": round(random.uniform(1.0, 6.0), 2),  # meters
        "wind_speed": round(random.uniform(10, 120), 2),    # km/h
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    response = requests.post(API_URL, json=data)
    print(f"Sent: {data}, Response: {response.status_code}")

if __name__ == "__main__":
    while True:
        send_sensor_data()
        time.sleep(10)  # Send every 10 seconds
