"""coastal_threats URL Configuration"""

from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse  # 👈 Add this import

# Define a simple home view
def home(request):
    return HttpResponse("<h1>Welcome to Coastal Threat Alert System</h1>")

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("users.urls")),
    path("api/alerts/", include("alerts.urls")),
    path("", home, name="home"), 
]
