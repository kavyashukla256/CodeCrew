import os
import requests
from celery import shared_task
from django.utils import timezone
from django.conf import settings
from .models import SensorData, Alert
from .utils.notifications import send_sms, send_push_to_token

OPENWEATHER_API_KEY = settings.OPENWEATHER_API_KEY
# Base API URLs
OPENWEATHER_CURRENT_URL = "https://api.openweathermap.org/data/2.5/weather"
OPENWEATHER_FORECAST_URL = "https://api.openweathermap.org/data/2.5/forecast"

# NOTE: For actual tide data, integrate NOAA or a similar API.
# Currently tide_level is left as None.

# -----------------------------
# TASK 1: Fetch weather for all stations
# -----------------------------
@shared_task
def fetch_and_process_weather():
    """
    Periodically fetch weather for predefined stations.
    """
    stations = [
        {"name": "StationA", "lat": 16.0, "lon": 73.0},
        {"name": "StationB", "lat": 15.5, "lon": 72.5},
    ]
    for s in stations:
        fetch_and_store_weather_for_station.delay(s["lat"], s["lon"], s["name"])


# -----------------------------
# TASK 2: Fetch and store single station weather
# -----------------------------
@shared_task
def fetch_and_store_weather_for_station(lat, lon, source_name="OpenWeather"):
    if not OPENWEATHER_API_KEY:
        print("ERROR: OPENWEATHER_API_KEY not configured")
        return

    params = {
        "lat": lat,
        "lon": lon,
        "appid": OPENWEATHER_API_KEY,
        "units": "metric"
    }

    try:
        response = requests.get(OPENWEATHER_CURRENT_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        print(f"Weather fetch error for {lat},{lon}: {e}")
        return

    # Extract metrics
    wind_speed = data.get("wind", {}).get("speed")
    pressure = data.get("main", {}).get("pressure")
    wave_height = data.get("waves", {}).get("height") if "waves" in data else None  # Placeholder
    tide_level = None  # TODO: Integrate NOAA or local tide API

    # Save Sensor Data
    sensor = SensorData.objects.create(
        latitude=lat,
        longitude=lon,
        wind_speed=wind_speed,
        wave_height=wave_height,
        tide_level=tide_level,
        pressure=pressure,
        raw=data,
        source=source_name
    )

    print(f"✅ Weather data saved for {lat},{lon}")
    check_for_threats.delay(sensor.id)


# -----------------------------
# TASK 3: Check for threats
# -----------------------------
@shared_task
def check_for_threats(sensor_id):
    """
    Rule-based simple threshold checks.
    """
    try:
        sensor = SensorData.objects.get(id=sensor_id)
    except SensorData.DoesNotExist:
        print(f"SensorData {sensor_id} not found")
        return

    alerts = []

    # High wind rule
    if sensor.wind_speed and sensor.wind_speed >= 20:
        alerts.append({
            "type": "High Wind",
            "severity": "warning" if sensor.wind_speed < 30 else "danger",
            "message": f"High wind expected: {sensor.wind_speed} m/s at ({sensor.latitude},{sensor.longitude})"
        })

    # High tide rule
    if sensor.tide_level and sensor.tide_level >= 3.0:
        alerts.append({
            "type": "High Tide",
            "severity": "warning",
            "message": f"Tide level {sensor.tide_level} m at ({sensor.latitude},{sensor.longitude})"
        })

    # High wave height rule
    if sensor.wave_height and sensor.wave_height >= 2.5:
        alerts.append({
            "type": "High Waves",
            "severity": "danger",
            "message": f"Wave height {sensor.wave_height} m at ({sensor.latitude},{sensor.longitude})"
        })

    # Save alerts & notify
    for a in alerts:
        alert_obj = Alert.objects.create(
            alert_type=a["type"],
            severity=a["severity"],
            message=a["message"],
            related_data=sensor
        )

        print(f"⚠️ ALERT: {a['message']}")
        send_alert_notifications(a)

    return len(alerts)


# -----------------------------
# Helper: Send notifications
# -----------------------------
def send_alert_notifications(alert):
    """
    Send SMS/Push notifications to subscribers.
    Replace with your subscriber DB or group.
    """
    subscribers = [
        {"phone": os.environ.get("ADMIN_PHONE", ""), "token": None},
    ]

    for sub in subscribers:
        if sub["phone"]:
            send_sms(sub["phone"], alert["message"])
        if sub["token"]:
            send_push_to_token(sub["token"], title=alert["type"], body=alert["message"])
# alerts/tasks.py
from celery import shared_task

@shared_task
def send_alert(message):
    print(f"Sending alert: {message}")
    # Add real notification logic here (SMS, email, push)
