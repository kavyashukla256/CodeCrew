from django.test import TestCase
from .models import SensorData, Alert

class ModelsTestCase(TestCase):
    def test_sensor_and_alert_creation(self):
        s = SensorData.objects.create(latitude=10.0, longitude=75.0, wind_speed=25.0)
        self.assertIsNotNone(s.id)
        a = Alert.objects.create(alert_type="Test Wind", severity="danger", message="Test", related_data=s)
        self.assertEqual(a.related_data, s)

