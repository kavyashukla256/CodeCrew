# alerts/urls.py
from rest_framework.routers import DefaultRouter
from .views import SensorDataViewSet, AlertViewSet

router = DefaultRouter()
router.register(r"data", SensorDataViewSet, basename="sensordata")
router.register(r"alerts", AlertViewSet, basename="alert")

urlpatterns = router.urls  # ✅ Directly assign router URLs
