from rest_framework import viewsets, permissions
from .models import SensorData, Alert
from .serializers import SensorDataSerializer, AlertSerializer

class SensorDataViewSet(viewsets.ModelViewSet):
    queryset = SensorData.objects.all().order_by("-timestamp")
    serializer_class = SensorDataSerializer
    permission_classes = [permissions.AllowAny]  # For now, allow all

class AlertViewSet(viewsets.ModelViewSet):
    queryset = Alert.objects.all().order_by("-created_at")
    serializer_class = AlertSerializer
    permission_classes = [permissions.AllowAny]  # For now, allow all
