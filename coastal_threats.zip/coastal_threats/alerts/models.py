from django.db import models
from django.conf import settings

class SensorData(models.Model):
    # Simple lat/lon fields (use GIS types in production)
    latitude = models.FloatField()
    longitude = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)
    # metric fields
    wind_speed = models.FloatField(null=True, blank=True)  # m/s
    wave_height = models.FloatField(null=True, blank=True) # meters
    tide_level = models.FloatField(null=True, blank=True)  # meters
    pressure = models.FloatField(null=True, blank=True)    # hPa
    raw = models.JSONField(null=True, blank=True)
    source = models.CharField(max_length=100, default="openweather")

    def __str__(self):
        return f"SensorData @ ({self.latitude},{self.longitude}) {self.timestamp}"

class Alert(models.Model):
    SEVERITY_CHOICES = (("info","Info"), ("warning","Warning"), ("danger","Danger"))
    alert_type = models.CharField(max_length=100)
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES, default="info")
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)
    related_data = models.ForeignKey(SensorData, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"[{self.severity}] {self.alert_type} - {self.created_at}"

