from django.contrib import admin
from .models import SensorData, Alert

@admin.register(SensorData)
class SensorDataAdmin(admin.ModelAdmin):
    list_display = ("id", "latitude", "longitude", "timestamp", "wind_speed", "wave_height", "tide_level", "source")
    list_filter = ("source",)

@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = ("id", "alert_type", "severity", "created_at", "resolved")
    list_filter = ("severity", "resolved")
    search_fields = ("alert_type", "message")
