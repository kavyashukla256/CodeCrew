import os
from twilio.rest import Client
import firebase_admin
from firebase_admin import messaging, credentials

TWILIO_ACCOUNT_SID = os.environ.get("AC34e517465f06db3792b15c77f47924a7")
TWILIO_AUTH_TOKEN = os.environ.get("1dfe78003c537c141fa43ff248bb9e03")
TWILIO_FROM_NUMBER = os.environ.get("TWILIO_FROM_NUMBER")

FIREBASE_CREDENTIALS_JSON = os.environ.get("FIREBASE_CREDENTIALS_JSON", "")

# initialize firebase admin once
if FIREBASE_CREDENTIALS_JSON and not firebase_admin._apps:
    cred = credentials.Certificate(FIREBASE_CREDENTIALS_JSON)
    firebase_admin.initialize_app(cred)

def send_sms(phone_number: str, message: str):
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER):
        print("Twilio not configured. Skipping SMS:", message)
        return False
    client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    try:
        client.messages.create(body=message, from_=TWILIO_FROM_NUMBER, to=phone_number)
        return True
    except Exception as e:
        print("Twilio send error:", e)
        return False

def send_push_to_token(device_token: str, title: str, body: str, data=None):
    if not firebase_admin._apps:
        print("Firebase not initialized. Skipping push.")
        return False
    message = messaging.Message(
        notification=messaging.Notification(title=title, body=body),
        token=device_token,
        data=data or {}
    )
    try:
        response = messaging.send(message)
        return response
    except Exception as e:
        print("Firebase send error:", e)
        return False
